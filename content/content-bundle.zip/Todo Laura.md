[[#Ponedeljek]]
[[#Torek]]
[[#Sreda]]
[[#Četrtek]]
[[#Petek]]

### **Ponedeljek**
- [ ] reči Maretu za gradivo za Vizualizacije iz Arhiva Viz, da se ga naroči (ko pride iz dopusta)
- [ ] seznanitev z Business Statementi v Datally: https://hei-aep-si001-p-we-wa-app-01.azurewebsites.net/DataApp/App/1/Page/2/Edit/1?ParentRouteId=3d1685a4-a1cc-4ec0-8e30-2896aa182aa3
- [x] Power BI model za DARS (glede na Albinov email)  [completion:: 2023-08-07]
- [x] Pošlji Sabini prve korake za ESEF, kar ti je Karmen poslala  [completion:: 2023-08-07]
- [x] Bookiraj sestanek z Maretom in Urbanom ✅ 2023-07-31
	- [x] Smart BI - popravi en zavihek ✅ 2023-07-21
	- [ ] pripravi navodila, kako naredim dashboard in mogoče po področjih
- [ ] https://addljsi.sharepoint.com/:w:/r/opr/_layouts/15/Doc.aspx?sourcedoc=%7B0FF3D3AC-22E4-45E5-A4C6-A03B14116AFA%7D&file=HSE_Studija_podatkovnih_virov_za_BI_vFinal.docx&action=default&mobileredirect=true
- [ ] Seznani se z gradivom za DE: https://add-opr.atlassian.net/wiki/spaces/DE/pages/24313891/DE+ROLE+OVERVIEW
- [ ] Poglej, kk je Karmen nardila IPI
- [x] Siliko: če jim še kake kazalnike nardimo.. preveri, če imamo dostop
- [ ] Čez Azure certificate materials: https://addljsi.sharepoint.com/opr/Shared%20Documents/Forms/AllItems.aspx?viewpath=%2Fopr%2FShared%20Documents%2FForms%2FAllItems%2Easpx&id=%2Fopr%2FShared%20Documents%2F04%20OPR%20Stebri%2F03%20DEV%2FAzure%20Certificate%20Material&viewid=7eb18f74%2Dc005%2D4a67%2D8346%2D4c858a3a97c1
	- [ ] delaj na SRCu pri Mateja Žitko Mateja.Zitko@src.si
- [ ] Databricks: https://addljsi.sharepoint.com/opr/_layouts/15/stream.aspx?id=%2Fopr%2FShared%20Documents%2F04%20OPR%20Stebri%2F99%20Skupno%2FKnowledge%20Share%20posnetki%2FDatabricks%20predstavitev%2D20230719%5F083943%2DMeeting%20Recording%2Emp4
- [ ] Project plan in Excel: https://addljsi.sharepoint.com/:u:/r/opr/Shared%20Documents/03%20OPR%20Projekti/Jub/01%20Project%20Management/Project%20Plan/JUB%20PZI%20-%20Project_Replan_23.7.mpp?csf=1&web=1&e=z8A8HO


### **Torek**
- [x] Pripravi strukturo za zapisnik: https://addljsi.sharepoint.com/:w:/r/opr/_layouts/15/Doc.aspx?sourcedoc=%7B6BA6B391-B2A5-40B3-941E-12E9E8F5EB37%7D&file=20220823_IGNITIS_MeetingMinutes%20-%20Solution%20Envisioning%20Workshop.docx&action=default&mobileredirect=true  [completion:: 2023-08-07]
- [ ] Dodaj projekte po podjetjih v Confluence https://add-opr.atlassian.net/wiki/spaces/Projects/pages/30638125/Overview
- [ ] Pripravi smernice za uporabo grafov v Power BIju
- [ ] Smart BI Dokumentacija: [Smart BI - Documentation.docx](https://addljsi.sharepoint.com/:w:/r/opr/Shared%20Documents/03%20OPR%20Projekti/R%26D%20-%20Paketek%20Corona/03%20Implementation/Instructions/Smart%20BI%20-%20Documentation.docx?d=w252a57608661483a9f1ebf46e3ccfd79&csf=1&web=1&e=JP7Edx)
- [ ] https://addljsi.sharepoint.com/:f:/r/opr/Shared%20Documents/03%20OPR%20Projekti/Snaga/Benchmarking%202014?csf=1&web=1&e=IoKk6s
- [ ] HR BI: [TFG HR - BUS Matrix and Technical Specificaction.xlsx](https://addljsi.sharepoint.com/:x:/r/opr/Shared%20Documents/03%20OPR%20Projekti/TFG/HR/02%20Specifications/99%20Blueprint/TFG%20HR%20-%20%20BUS%20Matrix%20and%20Technical%20Specificaction.xlsx?d=wcb9ba7f3c12b403c8d553e54b1082823&csf=1&web=1&e=nrpiEP)


### **Sreda**

- [ ] Poglej PBI po področjih:
	- [ ] Kemofarmacija: https://addljsi.sharepoint.com/:f:/r/opr/Shared%20Documents/03%20OPR%20Projekti/Kemofarmacija/Visual2019/PBI%20-%20Events%20Manu?csf=1&web=1&e=dhBUwv
	- [ ] NELT: https://addljsi.sharepoint.com/:f:/r/opr/Shared%20Documents/03%20OPR%20Projekti/Nelt%20Group?csf=1&web=1&e=fEhecu


### **Četrtek**

- [ ] ...


### **Petek**

- [ ] ...





