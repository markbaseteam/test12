Načrtovanje 
o	Delavnice so v tem koraku, ko je Presales končan
o	Načrtuje se vedno po področjih (finance, nabava, prodaja, itd.)
	področja, za katera mi preferiramo, da se delajo, so tista, ki so manj kompleksna, torej da imajo manj podatkov (finance se izogiba kot prvo področje) – oni podatkov iz ERPa ne vidijo kot ful vredno, veliko večja vrednost se stranki vidi, če uspemo proizvodnjo alpa nabavo spravit v BI (ostale podporne funkcije pa že kasneje spraviš v BI)
	Najprej se lotiš enega področja in ko ga končaš, nadaljuješ z drugem. Ne delamo načrtovanja prvega področja, nato drugega, in gremo šele nato na naslednjo fazo. Ampak je prav, da če se lotimo prodaje, z njo v celoti zaključimo (da za to področje nadaljujemo z ostalimi fazami, dokler ne pridemo do produkcije, da je to realizirano), in potem gremo naprej na naslednje področje.
•	Ker določene mere so v nekem področju realizirane in jih lahko uporabimo tudi na kakšnem drugem področju in če jih lahk v produkciji vidimo, jim je za naslednja področja dost bolj jasno, kako to izgleda. 
•	Če je zelo veliko področij pri nekem projektu, lahko razdelimo, da je na enem področju en BA, na drugem pa drug, kr tut od nas je nekdo boljši na enem področju, nekdo drug pa na drugem.
o	Tu ima BA glavno vlogo (planiranje delavnic, ki jih se mora imet s stranko)
	BA project: zbiranje podatkov od stranke, da lahko pripravimo model (BUS matrika za področja – mere, dimenzije), preveriš če lahko dobiš viewe od njih alpa da nam dajo kontakt od nekoga, ki nam lahk pri njih s tem pomaga
	Delavnice:
•	Najprej: Inicialna delavnica
o	zbiranje poslovnih vprašanj, na podlagi katerih se oblikuje, kaj želimo dobit ven iz tega modela – gap fit analiza
o	čim začnejo prihajat vprašanja, ki niso predvidena, temu rečemo “change request”
	In project management, a change request often arises when the client wants an addition or alteration to the agreed-upon deliverables for a project.
•	Nadaljnje delavnice (se gre bolj natančno čez vsebino)
o	Cilj je, da pridemo do:
	BUS matrike (high level)
•	Pripravimo vnaprej, da ne pridemo praznih rok na delavnico (lotiš se na delavnici nekega področja oz. skupine mer oz. facta – e.g.: iz glavne knjige, kaj želimo spremljat, oni rečejo kaj želijo spremljat in ti to sproti popisuješ)
o	Velikokrat se zgodi, da ko pišeš specifikacijo, ti dost manjka (dostkrat  se pri specifikaciji reče, da je to prva verzija specifikacije)
	Specifikacije oz. blueprinta oz. funkcionalne specifikacije (skupine mer, dimenzije, facte, vsaka mera – osnovna ali izračunana mera (oznaka: O / I)
•	To je dokumentacija, ki jo more BA pripravit za stranko. Sproti jo dopolnjuješ.
