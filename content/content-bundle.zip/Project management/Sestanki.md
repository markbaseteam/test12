interni sestanki za določen projekt, se ne tičejo posameznega področja
(pregled za projekt)


