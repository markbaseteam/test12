Support
o	Manjše projekte ima Mrak načez, pri večjih projektih pa je BA potem skos na tem projektu na support (ampak samo v primerju, da gre za velike posle – npr. DARS za 100 jurjev letno)
