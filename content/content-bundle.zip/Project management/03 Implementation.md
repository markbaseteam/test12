Razvoj (poteka po področjih – najprej se konča eno področje do konca po vseh fazah in šele nato se gre nazaj na drugo fazo za naslednje področje)
o	DE (primarno tipično on dela, ker gre za tehnični del)
	Ko gre iz druge faze na tretjo fazo, sta dve opcije
•	se DE-ja kontaktira v fazi načrtovanje, če je vključen na delavnice in spremlja, kaj mora potem razvit
•	se DE-ja vključi v fazi razvoja
o	BA (velikokrat vključen, ker se razvoj dela na podlagi specifikacije)  
