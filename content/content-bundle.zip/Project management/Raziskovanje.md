kakršenkoli research, ki ga narediš za določen projekt

ugotavljaš kero rešitev bi dal stranki (in ko raziskuješ kk narediš opcijo a, ki ti jo stranka potrdi)