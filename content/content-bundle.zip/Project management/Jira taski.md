
Projekt: Planiranje

Razvoj za planiranje investicij se sem piše, vse osalo pa na support

Issues:
- [[Sestanki]]
- [[Raziskovanje]]
- [[Načrtovanje]]
- [[Projektno vodenje]]

Daš v progress, ko delaš na projektu.

na backlogu in to do si ne piši ur


in progress -> in review (sama premakneš ko zaključiš s taskom - PM preveri s stranko če je vse kul) 

vse ostalo pa premika PM

