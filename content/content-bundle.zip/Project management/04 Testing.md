Test in stabilizacija (po področjih) – kr dolg process (90 % testiranja izvedemo v tem koraku)
o	BA
	on pripravi testno vizualizacijo in najprej sam nekaj klika – on testira v tem procesu – tu nimamo filinga za cifre še
	ponavadi imamo en tehnični kontakt (večinoma ITjevec na strani stranke) – on načeloma pripravi podatke za testiranje – in pol skupaj z njim testiramo, ker hitreje vidijo napako, kr vejo, kakšni so tipični podatki
•	Tehnični kontakt
•	Če imamo samo tehnični kotakt in nobenega power userja, ki mu bi lahko to znanje predali naprej, bo sledilo še testiranje s poslovnimi uporabniki
	Poslovni uporabniki
•	izobraževanja za več uporabnikov ali train the trainer iz podjetja in potem on naprej prenese znanje na uporabnike
	če imamo v tem koraku še kakšne želje po “razvoju” oz. želje za spremembe s strani uporabnikov, je to CR (change request)
•	če gre za javna naročila, se neme zadeva dat kot CR, ampak kot support (odvisno od stranke, interno pa temu rečemo CR)
o	ko zaznaš CR, je ključno, da na strani stranke dvigneš roko, in to omeniš
o	PM iz ADDja mora to uskladit s PMjem na strani stranke
