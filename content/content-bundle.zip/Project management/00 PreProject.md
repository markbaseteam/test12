Presales (traja dokler ponudba ni sprejeta)
o	To fazo vodi nekdo iz salesa.
o	Presales je na ravni celega projekta.
o	Vključen mora biti Business analyst (v tej fazi se ga določi in je zadolžen za celoten project), Data engineer in Project manager.
	Vloga BA-ja (ure si pišeš na project “presales”):
•	pomagat pripravit specifikacijo, kaj se bo delalo in s pomočjo DE-ja in Aljaža, da se pripravi arhitekturo (BA-ji je načeloma ne rišemo sami, razen če je zelo enostavna, jo lahko).
o	BA kontaktira DE-ja za arhitekturo
o	PM pripravi “projectplan” datoteko in Epice v Jiri
•	Časovnica: vsak za svoj del predvidi ure, kolk časa bo trajalo da nekaj nardimo (sales nakoncu ceno predvidi)
o	V template ponudbe: koraki storitve, pogoji,arhitektura (DE), predspostavke, projectplan
	Tipična ponudba: https://addljsi.sharepoint.com/:w:/r/opr/Shared%20Documents/02%20OPR%20Presales/SEL/13973-23_addBI_ponudba_SEL_uvedba_analitike_v1.0.docx?d=wa0d17e98b25549688daf23957fe0fbe5&csf=1&web=1&e=Ijnwjs 
