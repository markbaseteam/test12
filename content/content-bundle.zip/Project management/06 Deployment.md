Deploy na produkcijo 
o	Če se pojavi CR, se izobražuje potem marsikje oz. večinoma na produkciji (od tu naprej se dela support za to področje, če je idealni scenarij)
o	V vseh pogodbah je 12 mescih garancija, vse kar je kasneje je dodatno plačljivo (znotraj 12 mesecev je pa, da rečemo, da priznamo garancijo, al je pa to sprememba)
