[[Dimensional Modelling]]
- [ ] A se dela križce v BUS matriki glede na to, kje je mogoče naredit povezavo ali glede na to, kje bi podjetje želelo naredit povezavo? Pred sestankom za določeno področje si pripraviš tabelo za to področje, potem pa križce delaš tam, kjer oni izrazijo željo po prikazu v BI modelu?
- [ ] Kako je najbolj smiselno napisati Calendar tabelo v DAX-u? Uporabiti formulo ali spisati query? ... kr v modelu Cinkarne Celje je primer, ko je v DWH datumska dimenzija in si jo samo iz tam potegnil
- Navigation:
= Sql.Database("cc-bi-server.database.windows.net", "SQLDB_PROD")
- Source:
= Source{[Schema="DW_Star",Item="vw_DimDatum"]}[Data]

DT4DL (Digital Twin for Digital Lean) - med use casi se predlaga kot da se jim splača v to it

- digitalna strategija - bossplast (niso imeli BIja .. glede na albinov splošen predlog BUS matrike proizvodnje, smo prilagodili v 2 verzije (ena osnovna in ena naprednejša) - osnovna se je ocenlo kje bi se zdej dal analitiko delat kar majo v sistemih, naprednejša pa kar bi želeli nardit v naslednjih letih... in če jih BUS matriko pri digitalni strategiji nardijo)
- če maš predlog BUS matrike maš osnovnega in razširjenega (Albin celo  v treh)
- če ni assessmenta in strategije, se pa naredi ena verzija BUS matrike, ki se jo bo implementiralo

- [ ] how to import more measures at once in PBI?
	- https://www.youtube.com/watch?v=3TdSp-lCGNk
	- https://www.managility.co/bulk-measure-operations-in-power-bi/
- [ ] DevOps Sistema ni v ADDju. kaj to pomeni?
- gre za platformo (je alternativa Trellotu/GitHubu za projekt, task management)
- ful težko je delat propper scrum (ne moreš postavit stranko tk, da ne moreš delat nečesa drugega predn prvo stvar dokončaš)
- metoda scruma, ne tolk kanbana kot Jira

- [ ] zakaj bi podjetja želela imet fiskalno leto različno od koledarskega? (si že vprašala Karmen)
- Companies that experience significant seasonality in their business might align their fiscal year with their peak operational period. (retail companies after december)
- A fiscal year that doesn't align with the calendar year can better match the company's budgeting, planning, and operational cycles.
- Some companies might have regulatory or legal requirements that influence their choice of fiscal year.
- [ ] implementacija helpdeska (sistem, da oni tam dajo ticket) - da se vidi update statusa problema in rešitev - po tem toolu se mora dat searchat
- in pol se stranki reče: mi delamo na tak način, da nam v ta tool pošiljaš na support (če se nekaj nekomu pošlje na mejl, ko je na dopustu, drugi tega ne moremo videt - in tu bi nam helpdesk pripomogel, ker bi ta ticket lahk ta čas nekdo drug rešu)
- tool RCG Helpdesk
- https://www.comparitech.com/net-admin/it-help-desk-software-tools/

kaj si naredu in na kakšen način si nekaj naredu - to pogrešamo v ADDju (katere korake si naredu in da tehnično programerju rečeš, kaj mora naredit)

