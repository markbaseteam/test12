Cilj je, da vsak pokriva vsaj en del teh standardnih projektov.

Od javne uprave relativno hitro dobiš dnar in tut ohraniš nek mesečni fee.

Retail (firme, ki prodajajo stvari) bomo bolj pushali zarad teh, ki so na Studiu Moderna delali s tem.