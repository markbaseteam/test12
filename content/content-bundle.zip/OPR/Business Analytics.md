Business Analytics refers to the practice of analyzing data to gain valuable insights and make informed business decisions.

It involves the use of various tools and technologies to extract, transform, and visualize data. 
- [[Power BI]] / [[Pyramid Analytics]], [[Microsoft Azure]], and [[Smart BI/SQL]] are three powerful components often utilized in the field of Business Analytics.

[[Power BI]] / [[Pyramid Analytics]] comparison:
- 40 mio podatkov: Pyramid je za ful več podatkov - je rabil 5 min, PBI pa je rabu uro in pol
- Pyramid: dražji?
- Oba sta On Prem in v Cloudu

By leveraging Power BI, Microsoft Azure, and SQL together, businesses can effectively analyze their data, uncover patterns and trends, and derive actionable insights for improved decision-making and strategic planning.