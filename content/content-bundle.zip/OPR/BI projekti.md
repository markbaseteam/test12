Razlika med projekti:
- [[Data Assessment and Strategy]]
- [[Digital Assessment and Strategy]]
- [[Digital Analytics]]

Fundamentals = gre razvoj aplikacije,  

Maturity Assessment = projekt, pri katerem ocenjuješ zrelost organizacije s pomočjo intervjuja