digital je pa širše, da maš poleg podatkovnega vidika še digiital vidik (microsoft metodologija - 4 glavni stebri - capability ocenjuješ - customer experience/engage your customers, employees empowerment, pametni produkti/smart products-ML, AI - klime in aplikacija in digitalniposlovni model, optimize your operations - da procese opazuješ in optimiziraš - optimizacija in avtomatizacija) - povsod tu pride neka analitika zrvan - in greš po tem  - gledaš te stvari 

Primer projekta:
- [Podjetje Bossplast](https://addljsi.sharepoint.com/:f:/r/opr/Shared%20Documents/03%20OPR%20Projekti/Bossplast/Digitalna%20strategija/01%20Project%20Management?csf=1&web=1&e=S4hSPY)

