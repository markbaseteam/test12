It is a product from SqlBI and is useful when you want more from your Power BI reports.

In your Power BI report, you can import [[Visualizations]] from the AppSource marketplace (e.g.: vizualization created by OKViz). You are always using the version currently published. When the visual is updated on the AppSource marketplace, your reports are automatically updated to use that version.