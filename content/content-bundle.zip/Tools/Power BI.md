Power BI is a business intelligence tool that enables users to create interactive [[Visualizations]] and reports from multiple data sources. It provides a user-friendly interface for data exploration and analysis.

[[DAX]] (Data Analysis Expressions) is a formula expression language and can be used in different BI and visualization tools such as Power BI.