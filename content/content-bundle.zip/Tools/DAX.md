DAX (Data Analysis Expressions) is a library of functions and operators that can be combined to build formulas and expressions in [[Power BI]], Analysis Services, and Power Pivot in Excel data models.

DAX provides a rich set of functions, operators, and syntax that allow users to create custom calculations, manipulate data, and define relationships between tables. With DAX, you can perform calculations such as aggregations, filtering, data transformations, and create calculated columns and measures.

[Watch course](https://www.sqlbi.com/p/introducing-dax-video-course/)