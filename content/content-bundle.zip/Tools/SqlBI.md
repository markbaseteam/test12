Two guys from SqlBI created a product [[OKViz]] and is useful when you want more from your Power BI reports.

Courses:
- [[Dashboard Design Course]]