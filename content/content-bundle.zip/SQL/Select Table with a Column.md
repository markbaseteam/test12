Query, ki poišče, v katerih tabelah so specifični stolpci:
- v spodnji SQL kodi spremeniš: ColumnName

```SQL
SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE COLUMN_NAME = 'ColumnName'
```


nisem fix, če daš ColumnName v navednice ali jih izbrišeš