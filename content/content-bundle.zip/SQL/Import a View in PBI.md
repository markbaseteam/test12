I want to Import a View in PBI with a specific column.
- I don't remember a name of that View.
	- Sollution: [[Select View with a Column]]
- This View doesn't exit. I just have a query that returns a table.
	- Sollution: [[Create a View in SSMS]]