I want to make a relationship between all tables that have a specific column.
- Sollution: [[Select Table with a Column]]

I want to [[Import a View in PBI]] with a specific column.