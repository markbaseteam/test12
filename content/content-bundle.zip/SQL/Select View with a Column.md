1. Podan: 1 stolpec
Query, ki poišče, v katerih View-ih je specifičen stolpec:
- v spodnji SQL kodi spremeniš: ColumnName

```SQL
SELECT
    TABLE_NAME AS ViewName,
    COLUMN_NAME AS ColumnName
FROM
    INFORMATION_SCHEMA.COLUMNS
WHERE
    COLUMN_NAME = 'ColumnName'
```


2. Podan: > 1 stolpec
Query, ki poišče, v katerih View-ih so specifični stolpci (pogleda za vsakega posebej in ne hkrati):
- v spodnji SQL kodi spremeniš: ColumnName1, ColumnName2, etc.

```SQL
SELECT
    TABLE_NAME AS ViewName,
    COLUMN_NAME AS ColumnName
FROM
    INFORMATION_SCHEMA.COLUMNS
WHERE
    COLUMN_NAME IN ('ColumnName2', 'ColumnName2')
```



