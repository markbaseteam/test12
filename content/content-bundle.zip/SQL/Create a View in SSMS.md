Primer SQL View-a DARS-a:
- ampak ko ustvariš View, ne moreš imeti v njem ORDER BY, zato to vrstico odstraniš in filtriraš znotraj Power BIja

Ko želiš iz Query-ja narediti View, mu v prvi vrstici dodaš:
- v spodnji SQL kodi spremeniš: ViewName (tako bo poimenovan ustvarjen View)

```SQL
CREATE VIEW ViewName AS
```


Kreiranje View-a:
1. Če je v Query-ju funkcija ORDER BY, vrstico, ki vključuje omenjeno funkcijo, izbrišeš. 
	- View ne sprejme funkcije ORDER BY, zato jo izbrišeš in šele v PBI modelu tabelo urejaš po velikosti.
```sql
ORDER BY  [Action Date] desc , AU.[AuthorizationName], S.SubmissionID, ActedOn
```
2. Query spremeniš tako, da mu v prvi vrstici dodaš:
```SQL
CREATE VIEW ViewName AS
```
3. Poženeš Query oz. klikneš na F5


Primer Query-ja, iz katerega kreiramo View, če ga poženemo:

```SQL
CREATE VIEW KepionStatus AS
SELECT AU.[AuthorizationName] [Plan]
  ,CONVERT(NVARCHAR(MAX), S.SubmissionID) + N'-' + S.Tag [Submission]
  ,UPPER(C1.Name) [Status]
  ,UPPER(C2.Name) [Action]  
  ,U.FullName [Action By]  
  ,CONVERT(datetime,
SWITCHOFFSET(CONVERT(datetimeoffset, ActedOn),
DATENAME(TzOffset, SYSDATETIMEOFFSET()))
) [Action Date]
FROM [dbo].[Authorizations] AU
INNER JOIN [dbo].[Submissions] S
ON AU.AuthorizationID = S.AuthorizationID
INNER JOIN [dbo].[Constants] C1
ON S.[Status] = C1.Value
INNER JOIN [dbo].[Activities] A
ON S.AuthorizationID = A.AuthorizationID
AND S.SubmissionID = A.SubmissionID
INNER JOIN [dbo].[Users] U
ON A.UserID = U.UserID
INNER JOIN [dbo].[Constants] C2
ON C2.Value = A.SubmissionAction
WHERE AU.Deleted = 0
AND S.Discarded = 0
AND C1.[Group] = 'SubmissionStatus'
AND C2.[Group] = 'SubmissionAction'
```