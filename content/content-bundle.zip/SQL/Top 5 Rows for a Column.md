1. Želimo: Vrstice s specifično vrednostjo stolpca v določeni dimenziji
Query, ki izpiše prvih 5 vrstic, kjer je vrednost stolpca enaka Value:
- v spodnji SQL kodi spremeniš: DatabaseName (e.g.: DW_Star), DimName (e.g.: DimKonto), ColumnName, Value
- dbo = database object

```SQL
SELECT TOP5*
FROM [DatabaseName].dbo.DimName
WHERE ColumnName = ‘Value’
```


2. Želimo: Vrstice iz določene dimenzije

```SQL
USE DatabaseName
SELECT TOP 5*
FROM DimName
```