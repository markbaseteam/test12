- Laura
```dataview
TASK
FROM "Business Analytics"
WHERE contains(tags, "#todo/laura")
SORT due asc
```

- ADD
```dataview
TASK
FROM "Business Analytics"
WHERE contains(tags, "#todo/add")
SORT due asc
```

- Todo
```dataview
TASK
FROM "Business Analytics"
WHERE contains(tags, "#todo")
SORT due asc
```
